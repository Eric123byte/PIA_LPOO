
package gymposem509.modelo;

import java.util.ArrayList;
import java.util.List;

public class GymPOSEM509 {
    
//    public static void main(String[] args) {
//        GestionClientesMorales g = new GestionClientesMorales();
//        Cliente c1 = new Cliente(1, "Juan", "Perez", "1234567890");
//        List<Cliente> clientes = new ArrayList<>();
//        
//        g.cargarClientes(clientes);
//        System.out.println(g.mostrarClientes(clientes));
//    }
    
}
